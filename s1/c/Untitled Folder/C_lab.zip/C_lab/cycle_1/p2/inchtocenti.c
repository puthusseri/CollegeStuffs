/* Program to convert inches to centimetres (1 inch = 2.54cm)*/
#include<stdio.h>
void main()
{
 float a;
 printf("INCHES TO CENTIMETRES CONVERTER :-\n");
 printf("Enter value in inches: ");
 scanf("%f",&a);
 printf("%f Inches --> %f Centemetres\n",a,a*2.54);
}
